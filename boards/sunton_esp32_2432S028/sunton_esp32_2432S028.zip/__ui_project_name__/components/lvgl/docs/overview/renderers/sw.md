# Software renderer

TODO

